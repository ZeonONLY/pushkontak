global.d = new Date()
global.calender = d.toLocaleDateString('id')

// --------------- INFO OWNER ------------- //
global.prefix = "." // command prefix
global.ownNumb = "6281399952796" // isi no kalian
global.ownName = "neckurmine" // isi nama kalian
global.namaCreator ="NECK - XD"
global.versionSc ="5.0"
global.namaBot ="NeckPUSH"
global.linkgc ="https://chat.whatsapp.com/GlgNa2XRMiIJaePfDylJEx"
global.namaproduk ="neckxx"
global.namaStore ="NECK STORE"


// --------------- BATAS INFO OWNER------------- //

//____________global apikey_________//

global.lol = 'GataDios' // ISI APIKEY LOL HUMAN LU

//_____________global payment_______//
global.Qris = 'https://telegra.ph/file/d228acf87d28f59c187ac.jpg'
global.dana = '081399952795'
global.gopay = '081399952795'
global.scan = 'sᴄᴀɴ ǫʀɪs ᴀʟʟ ᴘᴀʏᴍᴇɴᴛ ᴅɪ ᴀᴛᴀs'

//__________________ʙᴀᴛᴀs ᴘᴀʏᴍᴇɴᴛ_____________//

global.domain = 'https://serverpanel.pannelpriv.my.id' // Isi Domain Lu
global.apikey = 'ptla_Xc06iFu1FgA5WkKoWPTaEs9C8HWWjAD7yZ3PaQgLLdfo' // Isi Apikey Plta Lu
global.capikey = 'ptlc_zxpF3b6Jpvy8vIKKRfqnYMCUg6q2rYR67LynwQGCd24q' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

//__________________GLOBAL TESTI_______________//

global.testi ='https://telegra.ph/file/23193ac87b5cb884a9298.jpg' // ISI URL TESTI KALIAN
global.text1 ='ITU TESTI NECK STORE KAK' // UBH AJA JADI NAMA MU
global.text2 ='AMAN GA BANG? AMAN DONG' // G SH DI HPS

//______________BATAS TESTI_____________//


// --------------- GLOBAL MESS ------------- //
global.mess = {
     delay: '4000', // Set Jeda Atur Di sini 1000 = 1 detik
     eror: 'lagi eror kak maaf ha', 
     wait: 'Wait Kak Lagi Proses',
     group: 'Maaf Kak Fitur Ini Hanya Bisa Digunakan Di Dalam Group', 
     owner: 'lu siapa?\n*GAUSAH SO ASIK*',
     group: "khusus di dalam group",
     inf: "𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 ⚠️\n› sc ini di recode oleh neckMDt\n› jangan lupa subs yt saya\n› sc ini 100% free [ JUAL ? NERAKA BAWAH ]\n› happfun your day\n\n𝗥𝗨𝗟𝗘𝗦 𝗣𝗨𝗦𝗛 ‼️\n› maximal push 1 GC isinya 2k member\n  kalo mau di ubah di cofig.js\n› untuk fitur push yg gada set jeda nya\n  gua setting standard [ 3000 ] kalo mau\n  di ubah tinggal cek di file config.js\n› inget *jangan di jual mekk*\n\n\n*LINK YT :*\n\nhttps://youtube.com/@KIZH15\n\n*kizh Store :*\n\nhttps://wa.me/6281392861978"
}
// --------------- BATAS GLOBAL MESS ------------- //

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log(__filename+' updated!')
	delete require.cache[file]
	require(file)
})

/*
// --------------- ABOUT SC------------- //
  › SCWA BY KIZH STORE
  › BAILEYES WHISKY
  › PAPIRING CODE 
  › TQ TO
    - Alfa05
    - Quin

*/